
function sumarArreglo(Frankyn) {
    let suma = 0;
    for (let i = 0; i < Frankyn.length; i++) {
        suma += Frankyn[i];
    }
    return suma;
}


let ventas = [100, 200, 300, 400, 500];
console.log("Total:", sumarArreglo(ventas)); 
