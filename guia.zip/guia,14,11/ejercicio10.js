

let Frankyn = [15, 22, 33, 45, 68, 82, 91];


let mayoresA50 = Frankyn.filter(valor => valor > 50);

console.log("Originales:", Frankyn);
console.log("Mayores a 50:", mayoresA50); 
