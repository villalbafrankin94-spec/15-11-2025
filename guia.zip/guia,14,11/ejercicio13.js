
let Frankyn = [100, 250, 399, 75];


let aumento10 = Frankyn.map(valor => valor * 1.10);

console.log("Originales:", Frankyn);
console.log("Con 10% aumento:", aumento10); 
