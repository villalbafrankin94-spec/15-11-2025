
let numero = 50;        
let texto = "100";      


let resultado = texto + numero;  

console.log("Tipo de dato de 'resultado':", typeof resultado); 
console.log("Valor de 'resultado':", resultado);               