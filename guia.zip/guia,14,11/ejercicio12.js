
let Frankyn = ["Cliente A", "Cliente B", "Cliente C"];
console.log("Cola inicial:", Frankyn);


let atendido = Frankyn.shift();
console.log("Cliente atendido:", atendido);
console.log("Cola después de shift:", Frankyn);


Frankyn.unshift("Cliente Prioritario");
console.log("Cola final:", Frankyn);
