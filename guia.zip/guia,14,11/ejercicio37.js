
class ProductoFrankyn {
  constructor(nombreFrankyn, precioFrankyn, cantidadFrankyn) {
    this.nombreFrankyn = nombreFrankyn;
    this.precioFrankyn = precioFrankyn;
    this.cantidadFrankyn = cantidadFrankyn;
  }
  valorTotalFrankyn() {
    return this.precioFrankyn * this.cantidadFrankyn;
  }
  static categoriaBaseFrankyn() {
    return "General (Frankyn)";
  }
}

class ProductoElectronicoFrankyn extends ProductoFrankyn {
  constructor(nombreFrankyn, precioFrankyn, cantidadFrankyn, garantiaFrankyn) {
    super(nombreFrankyn, precioFrankyn, cantidadFrankyn);
    this.garantiaMesesFrankyn = garantiaFrankyn;
    this.categoriaFrankyn = "Electrónico";
  }
}

class ProductoAlimenticioFrankyn extends ProductoFrankyn {
  constructor(nombreFrankyn, precioFrankyn, cantidadFrankyn, fechaFrankyn) {
    super(nombreFrankyn, precioFrankyn, cantidadFrankyn);
    this.fechaVencimientoFrankyn = fechaFrankyn;
    this.categoriaFrankyn = "Alimenticio";
  }
}

class InventarioFrankyn {
  constructor() {
    this.productosFrankyn = [];
  }
  agregarFrankyn(productoFrankyn) {
    this.productosFrankyn.push(productoFrankyn);
  }
  buscarPorCategoriaFrankyn(categoriaFrankyn) {
    return this.productosFrankyn.filter(pFrankyn => pFrankyn.categoriaFrankyn === categoriaFrankyn);
  }
}


const tiendaFrankyn = new InventarioFrankyn();
tiendaFrankyn.agregarFrankyn(new ProductoElectronicoFrankyn("Laptop", 1200, 5, 24));
tiendaFrankyn.agregarFrankyn(new ProductoAlimenticioFrankyn("Pan", 2, 30, "2025-12-15"));

const electronicosFrankyn = tiendaFrankyn.buscarPorCategoriaFrankyn("Electrónico");
electronicosFrankyn.forEach(p => {
  console.log(`${p.nombreFrankyn} - $${p.precioFrankyn} - Stock: ${p.cantidadFrankyn}`);
  console.log(`Garantía: ${p.garantiaMesesFrankyn ?? "N/A"} meses`);
  console.log(`Valor total: $${p.valorTotalFrankyn()}\n`);
});
const alimenticiosFrankyn = tiendaFrankyn.buscarPorCategoriaFrankyn("Alimenticio");
alimenticiosFrankyn.forEach(p => {
  console.log(`${p.nombreFrankyn} - $${p.precioFrankyn} - Stock: ${p.cantidadFrankyn}`);
  console.log(`Vence el: ${p.fechaVencimientoFrankyn ?? "N/A"}`);
  console.log(`Valor total: $${p.valorTotalFrankyn()}\n`);
});