
function Frankyn(edad) {
  if (edad >= 18) {
    return true;
  } else {
    return false;
  }
}

function FrankynSimple(edad) {
  return edad >= 18;
}


console.log("Edad 20:", Frankyn(20));       
console.log("Edad 16:", Frankyn(16));       
console.log("Edad 20:", FrankynSimple(20)); 
console.log("Edad 16:", FrankynSimple(16)); 
