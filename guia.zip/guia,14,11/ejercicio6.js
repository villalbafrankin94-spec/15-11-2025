
const PI = 3.14159;


console.log("Valor de PI:", PI);


let Frankyn = "Hola";
Frankyn = "¡Hola, soy Frankyn!"; 

console.log("Mensaje:", Frankyn);


{
  let temporal = 5;
  const fija = 10;
  console.log("Dentro del bloque:", temporal, fija);
}
