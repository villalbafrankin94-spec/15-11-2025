
function verificarParImpar(Frankyn) {
    if (Frankyn % 2 === 0) {
        console.log(Frankyn + " es par");
    } else {
        console.log(Frankyn + " es impar");
    }
}


verificarParImpar(15);   
verificarParImpar(20);   
verificarParImpar(0);    
verificarParImpar(-3);   