
let Frankyn = ["El Quijote", "100 Años de Soledad", "Fahrenheit 451"];

console.log("Libros iniciales:", Frankyn.length);

Frankyn.push("Moby Dick");
console.log("Después de push:", Frankyn.length); 
console.log("Libros:", Frankyn);


let libroEliminado = Frankyn.pop();
console.log("Libro removido:", libroEliminado); 
console.log("Libros finales:", Frankyn.length); 
