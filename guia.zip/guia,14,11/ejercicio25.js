
class DireccionFrankyn {
  constructor(calleFrankyn, codigoPostalFrankyn) {
    this.calleFrankyn = calleFrankyn;
    this.codigoPostalFrankyn = codigoPostalFrankyn;
  }
}

class ClienteFrankyn {
  constructor(nombreFrankyn, direccionFrankyn) {
    this.nombreFrankyn = nombreFrankyn;
    this.direccionFrankyn = direccionFrankyn;
  }

  mostrarUbicacionFrankyn() {
    console.log(`${this.nombreFrankyn} vive en: ${this.direccionFrankyn.calleFrankyn}, CP ${this.direccionFrankyn.codigoPostalFrankyn}`);
  }
}

const miDireccionFrankyn = new DireccionFrankyn("Avenida Central 456", "10101");
const juanFrankyn = new ClienteFrankyn("Juan Pérez", miDireccionFrankyn);
juanFrankyn.mostrarUbicacionFrankyn();
