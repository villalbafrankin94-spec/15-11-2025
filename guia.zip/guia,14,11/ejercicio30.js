
import fs from "fs";

const fechaFrankyn = new Date().toISOString();
const contenidoFrankyn = `Log creado (Frankyn): ${fechaFrankyn}\n`;

fs.writeFile("log.txt", contenidoFrankyn, (errFrankyn) => {
  if (errFrankyn) {
    console.error("Error (Frankyn):", errFrankyn);
    return;
  }
  console.log("Archivo creado exitosamente (CREATE - Frankyn)");
});
