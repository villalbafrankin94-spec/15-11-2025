

const readline = require('readline');
const TASA_IMPUESTO = 0.15;

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Ingrese el precio: ", (Frankyn) => {
  let precio = Number(Frankyn);

  if (!isNaN(precio)) {
    let impuesto = precio * TASA_IMPUESTO;
    let total = precio + impuesto;

    console.log("Precio base:", precio);
    console.log("Impuesto (15%):", impuesto.toFixed(2));
    console.log("Total a pagar:", total.toFixed(2));
  } else {
    console.log("Error: Entrada inválida");
  }

  rl.close();
});
