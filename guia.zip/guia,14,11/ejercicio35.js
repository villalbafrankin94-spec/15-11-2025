
import fs from "fs";

const rutaFrankyn = "resumen_crud_frankyn.txt";


fs.writeFile(rutaFrankyn, "Inicio CRUD (Frankyn)\n", (errC) => {
  if (errC) return console.error("CREATE error (Frankyn):", errC);

  // APPEND
  fs.appendFile(rutaFrankyn, "Append (Frankyn)\n", (errA) => {
    if (errA) return console.error("APPEND error (Frankyn):", errA);

    
    fs.readFile(rutaFrankyn, "utf8", (errR, dataR) => {
      if (errR) return console.error("READ error (Frankyn):", errR);
      console.log("Contenido (Frankyn):\n", dataR);

      
      try {
        fs.unlinkSync(rutaFrankyn);
        console.log("DELETE OK (Frankyn)");
      } catch (errD) {
        console.error("DELETE error (Frankyn):", errD);
      }
    });
  });
});
