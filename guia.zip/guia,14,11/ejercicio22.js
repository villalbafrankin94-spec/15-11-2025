
class AutoEstaticoFrankyn {
  constructor(marcaFrankyn, modeloFrankyn) {
    this.marcaFrankyn = marcaFrankyn;
    this.modeloFrankyn = modeloFrankyn;
  }

  static informacionGeneralFrankyn() {
    return "Clase base para gestión de vehículos (Frankyn)";
  }
}

console.log(AutoEstaticoFrankyn.informacionGeneralFrankyn());

const carroFrankyn = new AutoEstaticoFrankyn("Ford", "Focus");
console.log(carroFrankyn.marcaFrankyn);