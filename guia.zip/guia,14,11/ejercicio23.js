
class AutoGetSetFrankyn {
  constructor(marcaFrankyn, velocidadInicialFrankyn) {
    this.marcaFrankyn = marcaFrankyn;
    this._velocidadFrankyn = velocidadInicialFrankyn;
  }

  set velocidadFrankyn(valorFrankyn) {
    if (valorFrankyn >= 0) {
      this._velocidadFrankyn = valorFrankyn;
    } else {
      console.log("Error: Velocidad no puede ser negativa (Frankyn)");
    }
  }

  get velocidadFrankyn() {
    return this._velocidadFrankyn;
  }
}

const carroGetSetFrankyn = new AutoGetSetFrankyn("Ford", 80);
console.log("Velocidad:", carroGetSetFrankyn.velocidadFrankyn);
carroGetSetFrankyn.velocidadFrankyn = 120;
carroGetSetFrankyn.velocidadFrankyn = -50; 
console.log("Velocidad actualizada:", carroGetSetFrankyn.velocidadFrankyn);