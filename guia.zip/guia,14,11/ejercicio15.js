
const Frankyn = (base, altura) => {
  return (base * altura) / 2;
};


const FrankynCorto = (base, altura) => (base * altura) / 2;


console.log("Área (versión completa):", Frankyn(10, 5));       
console.log("Área (versión corta):", FrankynCorto(10, 5));     
