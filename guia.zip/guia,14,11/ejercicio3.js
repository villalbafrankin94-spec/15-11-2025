
let nombreUsuario = "Frankyn";     
let _tempVariable = 42;            
let $precio = 19.99;               


const PI = 3.14159;                
const MAX_INTENTOS = 3;            


let edad = 25;
edad = 26;                        

const pais = "Colombia";
console.log("Nombre de usuario:", nombreUsuario);
console.log("Valor de la variable temporal:", _tempVariable);
console.log("Precio:", $precio);
console.log("Valor de PI:", PI);
      
