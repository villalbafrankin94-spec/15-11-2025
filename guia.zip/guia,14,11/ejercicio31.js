
import fs from "fs";

const nuevaLineaFrankyn = " --- Nueva entrada: Verificación OK (Frankyn)\n";

fs.appendFile("log.txt", nuevaLineaFrankyn, (errFrankyn) => {
  if (errFrankyn) {
    console.error("Error (Frankyn):", errFrankyn);
    return;
  }
  console.log("Dato agregado (APPEND - Frankyn)");
});
