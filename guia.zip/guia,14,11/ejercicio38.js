
import { EstudianteFrankyn, RegistroEstudiantesFrankyn } from "./estudiantesFrankyn.js";


const estudiante1 = new EstudianteFrankyn("Frankyn", 20);
const estudiante2 = new EstudianteFrankyn("Laura", 22);


const registro = new RegistroEstudiantesFrankyn();
registro.agregar(estudiante1);
registro.agregar(estudiante2);


console.log("Listado de estudiantes Frankyn:");
console.log(registro.mostrarTodos());
