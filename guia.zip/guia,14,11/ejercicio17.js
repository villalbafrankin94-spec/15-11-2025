
function Frankyn(fahrenheit) {
  if (fahrenheit >= 14 && fahrenheit < 32) {
    return "Temperatura baja";
  } else if (fahrenheit >= 32 && fahrenheit < 68) {
    return "Temperatura adecuada";
  } else if (fahrenheit >= 68 && fahrenheit < 96) {
    return "Temperatura alta";
  } else {
    return "Temperatura desconocida";
  }
}


console.log("25°F:", Frankyn(25));  
console.log("50°F:", Frankyn(50));  
console.log("85°F:", Frankyn(85));  
console.log("5°F:", Frankyn(5));    
