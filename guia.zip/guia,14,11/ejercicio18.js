
const Frankyn = (edad) => edad >= 18 ? "Permitido" : "Denegado";


console.log("17 años:", Frankyn(17)); 
console.log("35 años:", Frankyn(35)); 
