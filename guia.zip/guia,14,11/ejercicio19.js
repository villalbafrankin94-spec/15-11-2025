
function Frankyn(nombre, curso) {
  console.log(`Bienvenido, ${nombre}!`);
  console.log(`Estás inscrito en el curso: ${curso}`);
  console.log("Comencemos a programar.");
}

Frankyn("Esteban", "Fundamentos de JavaScript");
Frankyn("María", "Programación Web");
