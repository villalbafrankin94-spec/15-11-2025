
import fs from "fs";

function actualizarContenidoFrankyn(nuevoContenidoFrankyn) {
  fs.writeFile("log.txt", nuevoContenidoFrankyn, (errFrankyn) => {
    if (errFrankyn) {
      console.error("Error (Frankyn):", errFrankyn);
      return;
    }
    console.log("Archivo actualizado (UPDATE - Frankyn)");
  });
}

const contenidoActualizadoFrankyn = "Registro actualizado (Frankyn): " + new Date().toLocaleString() + "\n";
actualizarContenidoFrankyn(contenidoActualizadoFrankyn);
