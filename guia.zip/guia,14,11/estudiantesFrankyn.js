
export class EstudianteFrankyn {
  constructor(nombre, edad) {
    this.nombre = nombre;
    this.edad = edad;
  }

  obtenerInfo() {
    return `Nombre: ${this.nombre}, Edad: ${this.edad}`;
  }
}

export class RegistroEstudiantesFrankyn {
  constructor() {
    this.lista = [];
  }

  agregar(estudiante) {
    this.lista.push(estudiante);
  }

  mostrarTodos() {
    return this.lista.map(e => e.obtenerInfo()).join("\n");
  }
}
