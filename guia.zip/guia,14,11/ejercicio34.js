
import fs from "fs";

const archivoFrankyn = "temporal.txt";
if (fs.existsSync(archivoFrankyn)) {
  try {
    fs.unlinkSync(archivoFrankyn);
    console.log(`Archivo '${archivoFrankyn}' eliminado exitosamente (Frankyn)`);
  } catch (errFrankyn) {
    console.error("Error al eliminar (Frankyn):", errFrankyn);
  }
} else {
  console.log(`El archivo '${archivoFrankyn}' no existe (Frankyn)`);
}
