
class GestionTareasFrankyn {
  constructor() {
    this.tareasFrankyn = [];
  }
  agregarFrankyn(tareaFrankyn) {
    this.tareasFrankyn.push(tareaFrankyn);
    console.log(`Tarea agregada (Frankyn): "${tareaFrankyn}"`);
  }
  completarFrankyn(indiceFrankyn) {
    if (indiceFrankyn >= 0 && indiceFrankyn < this.tareasFrankyn.length) {
      this.tareasFrankyn[indiceFrankyn] = "V " + this.tareasFrankyn[indiceFrankyn];
      console.log("Tarea marcada como completada (Frankyn)");
    } else {
      console.log("Índice inválido (Frankyn)");
    }
  }
  obtenerEstadisticasFrankyn() {
    const totalFrankyn = this.tareasFrankyn.length;
    const completadasFrankyn = this.tareasFrankyn.filter(tFrankyn => tFrankyn.startsWith("V")).length;
    const pendientesFrankyn = totalFrankyn - completadasFrankyn;
    return { totalFrankyn, completadasFrankyn, pendientesFrankyn };
  }
  mostrarFrankyn() {
    console.log("\n === LISTA DE TAREAS (Frankyn) === ");
    this.tareasFrankyn.forEach((tareaFrankyn, iFrankyn) => {
      console.log(`${iFrankyn}. ${tareaFrankyn}`);
    });
  }
}


const misTareasFrankyn = new GestionTareasFrankyn();
misTareasFrankyn.agregarFrankyn("Estudiar JavaScript");
misTareasFrankyn.agregarFrankyn("Hacer ejercicio");
misTareasFrankyn.mostrarFrankyn();
misTareasFrankyn.completarFrankyn(0);
misTareasFrankyn.mostrarFrankyn();
console.log("Estadísticas (Frankyn):", misTareasFrankyn.obtenerEstadisticasFrankyn());
