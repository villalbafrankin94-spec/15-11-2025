
class BaseDeDatosSingletonFrankyn {
  constructor(urlFrankyn) {
    if (BaseDeDatosSingletonFrankyn.instanciaFrankyn) {
      return BaseDeDatosSingletonFrankyn.instanciaFrankyn;
    }
    this.urlFrankyn = urlFrankyn;
    this.conectadoFrankyn = true;
    BaseDeDatosSingletonFrankyn.instanciaFrankyn = this;
  }
}

const db1Frankyn = new BaseDeDatosSingletonFrankyn("servidor_prod");
const db2Frankyn = new BaseDeDatosSingletonFrankyn("servidor_test");
console.log("URL db1:", db1Frankyn.urlFrankyn); 
console.log("URL db2:", db2Frankyn.urlFrankyn); 
console.log("¿Misma instancia?", db1Frankyn === db2Frankyn); 
