
let Frankyn = [
  "Hacer cama",
  "Comprar pan",
  "Estudiar JS",
  "Lavar platos"
];

console.log("Inicial:", Frankyn);


Frankyn.splice(1, 1, "Pasear al perro");

console.log("Final:", Frankyn);

