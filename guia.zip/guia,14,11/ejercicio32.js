
import fs from "fs";

fs.readFile("log.txt", "utf8", (errFrankyn, dataFrankyn) => {
  if (errFrankyn) {
    console.error("Error al leer (Frankyn):", errFrankyn);
    return;
  }
  console.log(" === Contenido de log.txt (Frankyn) === ");
  console.log(dataFrankyn);
  console.log(" ====================================== ");
});
